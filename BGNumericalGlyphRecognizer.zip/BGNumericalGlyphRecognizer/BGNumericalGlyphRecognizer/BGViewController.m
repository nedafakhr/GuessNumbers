//
//  BGViewController.m
//  BGMultistrokeNumberRecognizer
//
//  Created by Ben Gotow on 1/27/13.
//  Copyright (c) 2013 Ben Gotow. All rights reserved.
//

#import "BGViewController.h"

@interface BGViewController ()

@end

@implementation BGViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
