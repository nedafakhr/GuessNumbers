//
//  main.m
//  BGMultistrokeNumberRecognizer
//
//  Created by Ben Gotow on 1/27/13.
//  Copyright (c) 2013 Ben Gotow. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BGAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BGAppDelegate class]));
    }
}
