//
//  WTMGlyphTests.h
//  WTMGlyphTests
//
//  Created by Brit Gardner on 5/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface WTMGlyphTests : SenTestCase {
@private
    
}

@end
