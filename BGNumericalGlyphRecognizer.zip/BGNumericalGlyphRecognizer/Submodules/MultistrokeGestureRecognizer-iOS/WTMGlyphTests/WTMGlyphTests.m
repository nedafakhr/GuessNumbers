//
//  WTMGlyphTests.m
//  WTMGlyphTests
//
//  Created by Brit Gardner on 5/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "WTMGlyphTests.h"


@implementation WTMGlyphTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in WTMGlyphTests");
}

@end
