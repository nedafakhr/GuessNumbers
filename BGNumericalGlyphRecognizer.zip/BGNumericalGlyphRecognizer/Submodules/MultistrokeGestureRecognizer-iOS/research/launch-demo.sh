open demo/aimgroup/proj/dollar/ndollar.html
